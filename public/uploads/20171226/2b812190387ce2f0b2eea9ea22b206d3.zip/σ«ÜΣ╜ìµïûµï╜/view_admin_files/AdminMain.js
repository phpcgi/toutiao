﻿var AdminMain = function () {

	var loadStart = function () {
		
			//修改密码
			var $modifyModal = $('#modify_passwd');
			
			$("#modifyPasswdBtn").click(function(){
				$('body').modalmanager('loading');
		     	$modifyModal.load(pathUrl + '/server/user/modifyPasswordModal',{}, 
	     			function(){
	     				$modifyModal.modal();
	     			}
		     	);
			});
			
			$modifyModal.delegate('#submitBtn','click',function(){
				var options = {
					dataType : "json",
					type : "POST",
					url : pathUrl + '/server/user/modifyPassword',
					success : function(json) {
						if(json.success) {
							$modifyModal.modal("hide");
						} else {
							alert('修改失败 message:' + json.message);
						}
					}
				};
				if ($(".form-horizontal").validate().form()) {
					$modifyModal.find("form").ajaxForm().ajaxSubmit(options);
				}
			});
		
			var startALink = $('.start');
			if(startALink) {
				startALink.trigger("click");
			}
     }
	
	return {
        init: function () {
        	loadStart();
        }
    };
	
}();