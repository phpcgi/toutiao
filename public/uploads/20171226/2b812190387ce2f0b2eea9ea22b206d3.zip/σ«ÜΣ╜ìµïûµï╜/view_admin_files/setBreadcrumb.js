(function(){
    var breadcrumb = $('.breadcrumb');
    var title;
    breadcrumb.append($('.page-sidebar-menu>.start>.ajaxify>i').clone());
    breadcrumb.append(" ");
    breadcrumb.append($('.page-sidebar-menu>.start>.ajaxify').find('.title').clone());
    title = $('.page-sidebar-menu>.start>.ajaxify').find('.title').text();

    var activeClass = $('.page-sidebar-menu>.active').attr('class');
    if(activeClass.indexOf('start') == -1) {
        breadcrumb.append(' <i class="fa fa-angle-right"></i> ');
        breadcrumb.append(" ");
        breadcrumb.append($('.page-sidebar-menu>.active>a>i').clone());
        breadcrumb.append(" ");
        breadcrumb.append($('.page-sidebar-menu>.active>a').find('.title').clone());
        breadcrumb.append(" ");
        breadcrumb.append(' <i class="fa fa-angle-right"></i> ');
        breadcrumb.append(" ");
        title = $('.sub-menu>.active>a').text();
        breadcrumb.append($('.sub-menu>.active>a').text());

    }
    $('.page-title').text(title)
})()

